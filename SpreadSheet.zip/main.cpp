#include <iostream>
#include "SpreadSheet.h"
#include "Interface.h"
using namespace std;

int main()
{
    Interface sheet;
    sheet.menu();

    return 0;
}
